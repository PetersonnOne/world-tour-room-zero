// Receives microphone PCM only after the explicit held recording control.
// Audio output remains silent. No data leaves this worklet except bounded PCM.
class RoomZeroCapture extends AudioWorkletProcessor {
  constructor(){
    super();this.chunk=new Float32Array(2048);this.used=0;this.total=0;this.stopped=false;
    this.port.onmessage=event=>{if(event.data==='stop')this.finish(false);};
  }
  flush(){if(this.used){const samples=this.chunk.slice(0,this.used);this.port.postMessage({samples},[samples.buffer]);this.used=0;}}
  finish(limit){if(this.stopped)return;this.stopped=true;this.flush();this.port.postMessage({done:true,limit});}
  process(inputs){
    if(this.stopped)return false;
    const input=inputs[0]?.[0];if(!input)return true;
    const maximum=24000*30;
    for(let i=0;i<input.length&&this.total<maximum;i++){
      this.chunk[this.used++]=input[i];this.total++;
      if(this.used===this.chunk.length)this.flush();
    }
    if(this.total>=maximum){this.finish(true);return false;}
    return true;
  }
}
registerProcessor('room-zero-capture',RoomZeroCapture);
